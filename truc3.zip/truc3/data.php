
<?php
include 'connet.php';

// Récupérer les données de la base de données
$sql = "SELECT idU, nom , prenom , login FROM user";
$result = $conn->query($sql);

$data = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Fermer la connexion à la base de données
$conn->close();

// Retourner les données au format JSON
echo json_encode($data);
?>
